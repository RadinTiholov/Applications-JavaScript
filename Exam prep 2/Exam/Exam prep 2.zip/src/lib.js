import {html, render} from 'https://unpkg.com/lit-html?module';
import page from "//unpkg.com/page/page.mjs";

export {
    html,
    render,
    page
}